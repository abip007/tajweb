﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class MonthlyBillController : Controller
    {
        // GET: MonthlyBill
        private MMS db = new MMS();
        public ViewResult Index()
        {
            var monthsetup = db.MonthlyBillSetUPs.ToList();
            return View(monthsetup);
        }
        [HttpPost]
        public ActionResult Create(FormCollection form)
        {
            if (ModelState.IsValid)
            {
                List<MemberCompanyInfo> memberinfo = db.MemberCompanyInfo.Where(s => s.status == "Y").ToList();
                List<MonthlyBillSetUP> billsetup = db.MonthlyBillSetUPs.ToList();

                foreach (var member in memberinfo)
                {
                    BillRegister billregister = new BillRegister();
                    billregister.BillDate = Convert.ToDateTime(form["BillDate"]);
                    billregister.memberId = member.memberId;
                    billregister.paid = "N";
                    billregister.Remarks = form["Remarks"].ToString();
                    db.BillRegisters.Add(billregister);
                    db.SaveChanges();
                    Billdetail billdetail = new Billdetail();
                    foreach (var bs in billsetup)
                    {
                        billdetail.BillID = billregister.BillID;
                        billdetail.Amount = bs.Amount;
                        billdetail.HeaderId = bs.HeaderId;
                        db.Billdetail.Add(billdetail);
                        db.SaveChanges();
                    }

                    
                }
            }
            return RedirectToAction("Index", "BillRegisters");
        }
    }
}